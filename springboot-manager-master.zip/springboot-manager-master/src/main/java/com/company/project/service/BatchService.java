package com.company.project.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.company.project.entity.BatchEntity;

/**
 * 批次
 *
 * @author HKX
 * @email *****@mail.com
 * @date 2022-07-15 14:42:24
 */
public interface BatchService extends IService<BatchEntity> {

}

