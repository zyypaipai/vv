package com.company.project.mapper;

import com.company.project.entity.BatchEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 批次
 * 
 * @author HKX
 * @email *****@mail.com
 * @date 2022-07-15 14:42:24
 */
public interface BatchMapper extends BaseMapper<BatchEntity> {
	
}
