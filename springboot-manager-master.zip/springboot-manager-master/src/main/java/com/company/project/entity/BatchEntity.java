package com.company.project.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableField;
import com.company.project.entity.BaseEntity;


import java.io.Serializable;
import java.util.Date;

import lombok.Data;

/**
 * 批次
 *
 * @author HKX
 * @email *****@mail.com
 * @date 2022-07-15 14:42:24
 */
@Data
@TableName("batch")
public class BatchEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 批次号
	 */
	@TableId("batch_id")
	private String batchId;

	/**
	 * 创建时间
	 */
	@TableField("create_time")
	private Date createTime;

	/**
	 * 结束时间
	 */
	@TableField("deadline_time")
	private Date deadlineTime;

	/**
	 * 申请等级(1.家庭不困难 2.家庭困难 3.家庭特殊困难)
	 */
	@TableField("batch_level")
	private Integer batchLevel;


}
