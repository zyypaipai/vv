package com.company.project.mapper;

import com.company.project.entity.SchooluserEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 学校用户信息表
 * 
 * @author HKX
 * @email *****@mail.com
 * @date 2022-07-15 13:35:21
 */
public interface SchooluserMapper extends BaseMapper<SchooluserEntity> {
	
}
