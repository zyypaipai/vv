package com.company.project.mapper;

import com.company.project.entity.Apply4clothEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 申请服装
 * 
 * @author HKX
 * @email *****@mail.com
 * @date 2022-07-15 14:42:36
 */
public interface Apply4clothMapper extends BaseMapper<Apply4clothEntity> {
	
}
