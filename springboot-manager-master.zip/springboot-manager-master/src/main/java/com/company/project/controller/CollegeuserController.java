package com.company.project.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.stereotype.Controller;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.core.metadata.IPage;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import java.util.List;
import com.company.project.common.utils.DataResult;

import com.company.project.entity.CollegeuserEntity;
import com.company.project.service.CollegeuserService;



/**
 * 学院用户信息表
 *
 * @author HKX
 * @email *****@mail.com
 * @date 2022-07-15 13:35:15
 */
@Controller
@RequestMapping("/")
public class CollegeuserController {
    @Autowired
    private CollegeuserService collegeuserService;


    /**
    * 跳转到页面
    */
    @GetMapping("/index/collegeuser")
    public String collegeuser() {
        return "collegeuser/list";
        }

    @ApiOperation(value = "新增")
    @PostMapping("collegeuser/add")
    @RequiresPermissions("collegeuser:add")
    @ResponseBody
    public DataResult add(@RequestBody CollegeuserEntity collegeuser){
        collegeuserService.save(collegeuser);
        return DataResult.success();
    }

    @ApiOperation(value = "删除")
    @DeleteMapping("collegeuser/delete")
    @RequiresPermissions("collegeuser:delete")
    @ResponseBody
    public DataResult delete(@RequestBody @ApiParam(value = "id集合") List<String> ids){
        collegeuserService.removeByIds(ids);
        return DataResult.success();
    }

    @ApiOperation(value = "更新")
    @PutMapping("collegeuser/update")
    @RequiresPermissions("collegeuser:update")
    @ResponseBody
    public DataResult update(@RequestBody CollegeuserEntity collegeuser){
        collegeuserService.updateById(collegeuser);
        return DataResult.success();
    }

    @ApiOperation(value = "查询分页数据")
    @PostMapping("collegeuser/listByPage")
    @RequiresPermissions("collegeuser:list")
    @ResponseBody
    public DataResult findListByPage(@RequestBody CollegeuserEntity collegeuser){
        Page page = new Page(collegeuser.getPage(), collegeuser.getLimit());
        LambdaQueryWrapper<CollegeuserEntity> queryWrapper = Wrappers.lambdaQuery();
        //查询条件示例
        //queryWrapper.eq(CollegeuserEntity::getId, collegeuser.getId());
        IPage<CollegeuserEntity> iPage = collegeuserService.page(page, queryWrapper);
        return DataResult.success(iPage);
    }

}
