package com.company.project.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.company.project.entity.SchooluserEntity;

/**
 * 学校用户信息表
 *
 * @author HKX
 * @email *****@mail.com
 * @date 2022-07-15 13:35:21
 */
public interface SchooluserService extends IService<SchooluserEntity> {

}

