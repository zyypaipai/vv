package com.company.project.mapper;

import com.company.project.entity.StudentEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 学生个人信息表
 * 
 * @author HKX
 * @email *****@mail.com
 * @date 2022-07-15 13:35:02
 */
public interface StudentMapper extends BaseMapper<StudentEntity> {
	
}
