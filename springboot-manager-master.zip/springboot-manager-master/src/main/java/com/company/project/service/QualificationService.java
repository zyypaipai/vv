package com.company.project.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.company.project.entity.QualificationEntity;

/**
 * 申请资格
 *
 * @author HKX
 * @email *****@mail.com
 * @date 2022-07-15 14:42:33
 */
public interface QualificationService extends IService<QualificationEntity> {

}

