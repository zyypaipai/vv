package com.company.project.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.stereotype.Controller;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.core.metadata.IPage;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import java.util.List;
import com.company.project.common.utils.DataResult;

import com.company.project.entity.ClothEntity;
import com.company.project.service.ClothService;



/**
 * 服装
 *
 * @author HKX
 * @email *****@mail.com
 * @date 2022-07-15 14:42:30
 */
@Controller
@RequestMapping("/")
public class ClothController {
    @Autowired
    private ClothService clothService;


    /**
    * 跳转到页面
    */
    @GetMapping("/index/cloth")
    public String cloth() {
        return "cloth/list";
        }

    @ApiOperation(value = "新增")
    @PostMapping("cloth/add")
    @RequiresPermissions("cloth:add")
    @ResponseBody
    public DataResult add(@RequestBody ClothEntity cloth){
        clothService.save(cloth);
        return DataResult.success();
    }

    @ApiOperation(value = "删除")
    @DeleteMapping("cloth/delete")
    @RequiresPermissions("cloth:delete")
    @ResponseBody
    public DataResult delete(@RequestBody @ApiParam(value = "id集合") List<String> ids){
        clothService.removeByIds(ids);
        return DataResult.success();
    }

    @ApiOperation(value = "更新")
    @PutMapping("cloth/update")
    @RequiresPermissions("cloth:update")
    @ResponseBody
    public DataResult update(@RequestBody ClothEntity cloth){
        clothService.updateById(cloth);
        return DataResult.success();
    }

    @ApiOperation(value = "查询分页数据")
    @PostMapping("cloth/listByPage")
    @RequiresPermissions("cloth:list")
    @ResponseBody
    public DataResult findListByPage(@RequestBody ClothEntity cloth){
        Page page = new Page(cloth.getPage(), cloth.getLimit());
        LambdaQueryWrapper<ClothEntity> queryWrapper = Wrappers.lambdaQuery();
        //查询条件示例
        //queryWrapper.eq(ClothEntity::getId, cloth.getId());
        IPage<ClothEntity> iPage = clothService.page(page, queryWrapper);
        return DataResult.success(iPage);
    }

}
