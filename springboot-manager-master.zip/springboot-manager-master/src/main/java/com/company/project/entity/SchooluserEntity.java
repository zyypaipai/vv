package com.company.project.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableField;
import com.company.project.entity.BaseEntity;


import java.io.Serializable;
import java.util.Date;

import lombok.Data;

/**
 * 学校用户信息表
 *
 * @author HKX
 * @email *****@mail.com
 * @date 2022-07-15 13:35:21
 */
@Data
@TableName("schooluser")
public class SchooluserEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * id
	 */
	@TableId("id")
	private Integer id;

	/**
	 * 密码
	 */
	@TableField("password")
	private String password;

	/**
	 * 用户名
	 */
	@TableField("username")
	private String username;

	/**
	 * 电话号码
	 */
	@TableField("phone")
	private String phone;

	/**
	 * 是否删除(1未删除；0已删除)
	 */
	@TableField("deleted")
	private Integer deleted;


}
