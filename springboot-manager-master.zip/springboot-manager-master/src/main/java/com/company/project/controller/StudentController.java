package com.company.project.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.stereotype.Controller;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.core.metadata.IPage;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import java.util.List;
import com.company.project.common.utils.DataResult;

import com.company.project.entity.StudentEntity;
import com.company.project.service.StudentService;



/**
 * 学生个人信息表
 *
 * @author HKX
 * @email *****@mail.com
 * @date 2022-07-15 13:35:02
 */
@Controller
@RequestMapping("/")
public class StudentController {
    @Autowired
    private StudentService studentService;


    /**
    * 跳转到页面
    */
    @GetMapping("/index/student")
    public String student() {
        return "student/list";
        }

    @ApiOperation(value = "新增")
    @PostMapping("student/add")
    @RequiresPermissions("student:add")
    @ResponseBody
    public DataResult add(@RequestBody StudentEntity student){
        studentService.save(student);
        return DataResult.success();
    }

    @ApiOperation(value = "删除")
    @DeleteMapping("student/delete")
    @RequiresPermissions("student:delete")
    @ResponseBody
    public DataResult delete(@RequestBody @ApiParam(value = "id集合") List<String> ids){
        studentService.removeByIds(ids);
        return DataResult.success();
    }

    @ApiOperation(value = "更新")
    @PutMapping("student/update")
    @RequiresPermissions("student:update")
    @ResponseBody
    public DataResult update(@RequestBody StudentEntity student){
        studentService.updateById(student);
        return DataResult.success();
    }

    @ApiOperation(value = "查询分页数据")
    @PostMapping("student/listByPage")
    @RequiresPermissions("student:list")
    @ResponseBody
    public DataResult findListByPage(@RequestBody StudentEntity student){
        Page page = new Page(student.getPage(), student.getLimit());
        LambdaQueryWrapper<StudentEntity> queryWrapper = Wrappers.lambdaQuery();
        //查询条件示例
        //queryWrapper.eq(StudentEntity::getId, student.getId());
        IPage<StudentEntity> iPage = studentService.page(page, queryWrapper);
        return DataResult.success(iPage);
    }

}
