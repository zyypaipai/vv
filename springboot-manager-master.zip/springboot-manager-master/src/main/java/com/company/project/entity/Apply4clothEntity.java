package com.company.project.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableField;
import com.company.project.entity.BaseEntity;


import java.io.Serializable;
import java.util.Date;

import lombok.Data;

/**
 * 申请服装
 *
 * @author HKX
 * @email *****@mail.com
 * @date 2022-07-15 14:42:36
 */
@Data
@TableName("apply4cloth")
public class Apply4clothEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 学号
	 */
	@TableId("id")
	private String id;

	/**
	 * 性别(1.男 2.女)
	 */
	@TableField("sex")
	private Integer sex;

	/**
	 * 服装编号
	 */
	@TableField("cloth_id")
	private String clothId;

	/**
	 * 服装大小(1.S 2.M 3.L 4.XL)
	 */
	@TableField("cloth_size")
	private Integer clothSize;

	/**
	 * 服装风格
	 */
	@TableField("style")
	private String style;

	/**
	 * 状态(1:申请中 2:申请结束)
	 */
	@TableField("apply_status")
	private Integer applyStatus;


}
