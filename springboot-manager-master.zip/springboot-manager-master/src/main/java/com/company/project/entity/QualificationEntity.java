package com.company.project.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableField;
import com.company.project.entity.BaseEntity;


import java.io.Serializable;
import java.util.Date;

import lombok.Data;

/**
 * 申请资格
 *
 * @author HKX
 * @email *****@mail.com
 * @date 2022-07-15 14:42:33
 */
@Data
@TableName("qualification")
public class QualificationEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 学号
	 */
	@TableId("id")
	private String id;

	/**
	 * 批次号
	 */
	@TableField("batch_id")
	private String batchId;

	/**
	 * 申请等级(1.家庭不困难 2.家庭困难 3.家庭特殊困难)
	 */
	@TableField("student_level")
	private Integer studentLevel;

	/**
	 * 申请理由
	 */
	@TableField("apply_reason")
	private String applyReason;

	/**
	 * 状态(1:申请中 2:申请结束)
	 */
	@TableField("qualification_status")
	private Integer qualificationStatus;

	/**
	 * 结果(1:申请成功 2:申请失败)
	 */
	@TableField("qualification_result")
	private Integer qualificationResult;

	/**
	 * 拒绝理由
	 */
	@TableField("refuse_reason")
	private String refuseReason;


}
