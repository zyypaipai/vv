package com.company.project.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.company.project.entity.ClothEntity;

/**
 * 服装
 *
 * @author HKX
 * @email *****@mail.com
 * @date 2022-07-15 14:42:30
 */
public interface ClothService extends IService<ClothEntity> {

}

