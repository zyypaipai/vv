package com.company.project.service.impl;

import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import com.company.project.mapper.CounsellorMapper;
import com.company.project.entity.CounsellorEntity;
import com.company.project.service.CounsellorService;


@Service("counsellorService")
public class CounsellorServiceImpl extends ServiceImpl<CounsellorMapper, CounsellorEntity> implements CounsellorService {


}