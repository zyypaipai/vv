package com.company.project.common.filter;

import lombok.Data;

/**
 * Created with IntelliJ IDEA.
 *
 * @author: HKX
 * @date: 2021/11/25
 * Description: No Description
 */
@Data
public class App {
    String from;
    String secret;
}
