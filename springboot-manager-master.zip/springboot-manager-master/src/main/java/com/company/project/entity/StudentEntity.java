package com.company.project.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableField;
import com.company.project.entity.BaseEntity;


import java.io.Serializable;
import java.util.Date;

import lombok.Data;

/**
 * 学生个人信息表
 *
 * @author HKX
 * @email *****@mail.com
 * @date 2022-07-15 13:35:02
 */
@Data
@TableName("student")
public class StudentEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * id
	 */
	@TableId("id")
	private Integer id;

	/**
	 * 学号
	 */
	@TableField("s_id")
	private Integer sId;

	/**
	 * 密码
	 */
	@TableField("password")
	private String password;

	/**
	 * 用户名
	 */
	@TableField("username")
	private String username;

	/**
	 * 真实姓名
	 */
	@TableField("realname")
	private String realname;

	/**
	 * 电话号码
	 */
	@TableField("phone")
	private String phone;

	/**
	 * 性别
	 */
	@TableField("sex")
	private String sex;

	/**
	 * 困难等级
	 */
	@TableField("level")
	private String level;

	/**
	 * 所在年级学院
	 */
	@TableField("grade")
	private String grade;

	/**
	 * 所属大学
	 */
	@TableField("college")
	private String college;

	/**
	 * 是否删除(1未删除；0已删除)
	 */
	@TableField("deleted")
	private Integer deleted;


}
