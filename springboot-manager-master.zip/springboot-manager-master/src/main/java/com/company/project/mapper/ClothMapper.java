package com.company.project.mapper;

import com.company.project.entity.ClothEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 服装
 * 
 * @author HKX
 * @email *****@mail.com
 * @date 2022-07-15 14:42:30
 */
public interface ClothMapper extends BaseMapper<ClothEntity> {
	
}
