package com.company.project.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableField;
import com.company.project.entity.BaseEntity;


import java.io.Serializable;
import java.util.Date;

import lombok.Data;

/**
 * 服装
 *
 * @author HKX
 * @email *****@mail.com
 * @date 2022-07-15 14:42:30
 */
@Data
@TableName("cloth")
public class ClothEntity extends BaseEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 服装编号
	 */
	@TableId("cloth_id")
	private String clothId;

	/**
	 * 服装大小(1.S 2.M 3.L 4.XL)
	 */
	@TableField("cloth_size")
	private Integer clothSize;

	/**
	 * 服装风格
	 */
	@TableField("style")
	private String style;

	/**
	 * 性别(1.男 2.女)
	 */
	@TableField("sex")
	private Integer sex;

	/**
	 * 批次号
	 */
	@TableField("batch_id")
	private String batchId;

	/**
	 * 图片编码
	 */
	@TableField("photo")
	private String photo;


}
