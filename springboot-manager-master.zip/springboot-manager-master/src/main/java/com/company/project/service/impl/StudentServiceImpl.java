package com.company.project.service.impl;

import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import com.company.project.mapper.StudentMapper;
import com.company.project.entity.StudentEntity;
import com.company.project.service.StudentService;


@Service("studentService")
public class StudentServiceImpl extends ServiceImpl<StudentMapper, StudentEntity> implements StudentService {


}