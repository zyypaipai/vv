package com.company.project.service.impl;

import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import com.company.project.mapper.ClothMapper;
import com.company.project.entity.ClothEntity;
import com.company.project.service.ClothService;


@Service("clothService")
public class ClothServiceImpl extends ServiceImpl<ClothMapper, ClothEntity> implements ClothService {


}