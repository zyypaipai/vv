package com.company.project.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.company.project.entity.StudentEntity;

/**
 * 学生个人信息表
 *
 * @author HKX
 * @email *****@mail.com
 * @date 2022-07-15 13:35:02
 */
public interface StudentService extends IService<StudentEntity> {

}

