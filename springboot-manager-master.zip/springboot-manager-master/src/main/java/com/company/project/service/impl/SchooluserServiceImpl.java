package com.company.project.service.impl;

import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import com.company.project.mapper.SchooluserMapper;
import com.company.project.entity.SchooluserEntity;
import com.company.project.service.SchooluserService;


@Service("schooluserService")
public class SchooluserServiceImpl extends ServiceImpl<SchooluserMapper, SchooluserEntity> implements SchooluserService {


}