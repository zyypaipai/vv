package com.company.project.mapper;

import com.company.project.entity.CounsellorEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 辅导员个人信息表
 * 
 * @author HKX
 * @email *****@mail.com
 * @date 2022-07-15 13:35:08
 */
public interface CounsellorMapper extends BaseMapper<CounsellorEntity> {
	
}
