package com.company.project.service.impl;

import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import com.company.project.mapper.Apply4clothMapper;
import com.company.project.entity.Apply4clothEntity;
import com.company.project.service.Apply4clothService;


@Service("apply4clothService")
public class Apply4clothServiceImpl extends ServiceImpl<Apply4clothMapper, Apply4clothEntity> implements Apply4clothService {


}