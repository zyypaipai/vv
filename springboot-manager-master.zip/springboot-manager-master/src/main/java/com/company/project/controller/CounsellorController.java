package com.company.project.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.stereotype.Controller;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.core.metadata.IPage;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import java.util.List;
import com.company.project.common.utils.DataResult;

import com.company.project.entity.CounsellorEntity;
import com.company.project.service.CounsellorService;



/**
 * 辅导员个人信息表
 *
 * @author HKX
 * @email *****@mail.com
 * @date 2022-07-15 13:35:08
 */
@Controller
@RequestMapping("/")
public class CounsellorController {
    @Autowired
    private CounsellorService counsellorService;


    /**
    * 跳转到页面
    */
    @GetMapping("/index/counsellor")
    public String counsellor() {
        return "counsellor/list";
        }

    @ApiOperation(value = "新增")
    @PostMapping("counsellor/add")
    @RequiresPermissions("counsellor:add")
    @ResponseBody
    public DataResult add(@RequestBody CounsellorEntity counsellor){
        counsellorService.save(counsellor);
        return DataResult.success();
    }

    @ApiOperation(value = "删除")
    @DeleteMapping("counsellor/delete")
    @RequiresPermissions("counsellor:delete")
    @ResponseBody
    public DataResult delete(@RequestBody @ApiParam(value = "id集合") List<String> ids){
        counsellorService.removeByIds(ids);
        return DataResult.success();
    }

    @ApiOperation(value = "更新")
    @PutMapping("counsellor/update")
    @RequiresPermissions("counsellor:update")
    @ResponseBody
    public DataResult update(@RequestBody CounsellorEntity counsellor){
        counsellorService.updateById(counsellor);
        return DataResult.success();
    }

    @ApiOperation(value = "查询分页数据")
    @PostMapping("counsellor/listByPage")
    @RequiresPermissions("counsellor:list")
    @ResponseBody
    public DataResult findListByPage(@RequestBody CounsellorEntity counsellor){
        Page page = new Page(counsellor.getPage(), counsellor.getLimit());
        LambdaQueryWrapper<CounsellorEntity> queryWrapper = Wrappers.lambdaQuery();
        //查询条件示例
        //queryWrapper.eq(CounsellorEntity::getId, counsellor.getId());
        IPage<CounsellorEntity> iPage = counsellorService.page(page, queryWrapper);
        return DataResult.success(iPage);
    }

}
