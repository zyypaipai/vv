package com.company.project.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.stereotype.Controller;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.core.metadata.IPage;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import java.util.List;
import com.company.project.common.utils.DataResult;

import com.company.project.entity.Apply4clothEntity;
import com.company.project.service.Apply4clothService;



/**
 * 申请服装
 *
 * @author HKX
 * @email *****@mail.com
 * @date 2022-07-15 14:42:36
 */
@Controller
@RequestMapping("/")
public class Apply4clothController {
    @Autowired
    private Apply4clothService apply4clothService;


    /**
    * 跳转到页面
    */
    @GetMapping("/index/apply4cloth")
    public String apply4cloth() {
        return "apply4cloth/list";
        }

    @ApiOperation(value = "新增")
    @PostMapping("apply4cloth/add")
    @RequiresPermissions("apply4cloth:add")
    @ResponseBody
    public DataResult add(@RequestBody Apply4clothEntity apply4cloth){
        apply4clothService.save(apply4cloth);
        return DataResult.success();
    }

    @ApiOperation(value = "删除")
    @DeleteMapping("apply4cloth/delete")
    @RequiresPermissions("apply4cloth:delete")
    @ResponseBody
    public DataResult delete(@RequestBody @ApiParam(value = "id集合") List<String> ids){
        apply4clothService.removeByIds(ids);
        return DataResult.success();
    }

    @ApiOperation(value = "更新")
    @PutMapping("apply4cloth/update")
    @RequiresPermissions("apply4cloth:update")
    @ResponseBody
    public DataResult update(@RequestBody Apply4clothEntity apply4cloth){
        apply4clothService.updateById(apply4cloth);
        return DataResult.success();
    }

    @ApiOperation(value = "查询分页数据")
    @PostMapping("apply4cloth/listByPage")
    @RequiresPermissions("apply4cloth:list")
    @ResponseBody
    public DataResult findListByPage(@RequestBody Apply4clothEntity apply4cloth){
        Page page = new Page(apply4cloth.getPage(), apply4cloth.getLimit());
        LambdaQueryWrapper<Apply4clothEntity> queryWrapper = Wrappers.lambdaQuery();
        //查询条件示例
        //queryWrapper.eq(Apply4clothEntity::getId, apply4cloth.getId());
        IPage<Apply4clothEntity> iPage = apply4clothService.page(page, queryWrapper);
        return DataResult.success(iPage);
    }

}
