package com.company.project.service.impl;

import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import com.company.project.mapper.BatchMapper;
import com.company.project.entity.BatchEntity;
import com.company.project.service.BatchService;


@Service("batchService")
public class BatchServiceImpl extends ServiceImpl<BatchMapper, BatchEntity> implements BatchService {


}