package com.company.project.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.company.project.entity.Apply4clothEntity;

/**
 * 申请服装
 *
 * @author HKX
 * @email *****@mail.com
 * @date 2022-07-15 14:42:36
 */
public interface Apply4clothService extends IService<Apply4clothEntity> {

}

