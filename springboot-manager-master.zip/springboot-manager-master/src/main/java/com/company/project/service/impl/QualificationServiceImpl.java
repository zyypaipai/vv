package com.company.project.service.impl;

import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import com.company.project.mapper.QualificationMapper;
import com.company.project.entity.QualificationEntity;
import com.company.project.service.QualificationService;


@Service("qualificationService")
public class QualificationServiceImpl extends ServiceImpl<QualificationMapper, QualificationEntity> implements QualificationService {


}